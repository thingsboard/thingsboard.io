## 💡 Solution Description

The **Swimming Pool SCADA System** template is a production-ready accelerator for swimming pool facility management. It bridges the gap between mechanical pool equipment and modern IoT platforms, providing a unified SCADA interface for water quality, temperature control, and energy management.

### ✨ Highlights

Transform your swimming pool facility management with the **Swimming Pool SCADA System** solution template.
Designed for facility managers and system integrators, this solution brings advanced SCADA capabilities to pool operations, enhancing sustainability and efficiency. 🏊‍♂️📊

Press **Install** to generate a complete SCADA ecosystem — populated with device emulators, gateway configurations, and flow logic.

### 📦 What's inside the box?

We have auto-generated a comprehensive industrial platform for you:

* **🎛️ SCADA Dashboard:** A feature-rich dashboard offering real-time visualization of water temperature, pump status, and valve positions.
* **🤖 Modbus Emulator:** A complete Docker environment simulating 14 distinct devices (**Sand filter**, **Heat pump**, etc.), allowing you to see the solution in action immediately.
* **🧮 Flow Logic:** Pre-configured **Calculated Fields** that analyze valve states to visualize water flow through Filter, Heat, and Drain segments.
* **🚨 Equipment Alarms:** Automated rules that trigger on critical events, such as **Heat Pump Vibration** (>5.0), **Sand Filter Pressure** anomalies, or **Water Pump Overheating**.
* **📡 Auto-Configured Gateway:** The solution automatically configures the **Pool System Gateway** to communicate with the pool devices using the Modbus protocol.

### 🌟 Why use this template?

* **💧 Water Quality Management:** Automate the monitoring of the **Water level meter** and **Filter PH sensor** to ensure sanitary conditions without constant manual checking.
* **🌡️ Smart Temperature Control:** Integrate **Heat pump** telemetry to intelligently monitor compressor temperature and refrigerant pressure, ensuring consistent water temperature while optimizing energy usage.
* **⚙️ Equipment Health:** Prevent downtime by tracking the performance of the **Sand filter** and pumps through real-time monitoring of vibration, rotation speed, and pressure.

### ✨ Key Features

* **Unified SCADA View:** Consolidate data from 14 distinct subsystems (Valves, Pumps, Sensors, Heaters) into a single, real-time command center.
* **Complex Flow Logic:** Utilizes **Calculated Fields** to dynamically determine the flow status of specific pipe segments (Drain, Filter, Heat) based on the state of valves like the **Main intake valve** and **Pool weir valve**.
* **Remote Management:** Enable operators to remotely alter system states, such as switching operational modes or opening/closing specific valves.

### 🌍 Real-World Applications

This template serves as a robust foundation for various sectors:

* **🏊 Public Swimming Pools:**
  Centralize monitoring for municipal pools to reduce maintenance costs and ensure public safety.
* **🏨 Hotels & Spas:**
  Maintain premium guest experiences by ensuring perfect water temperature and clarity automatically.
* **🏞️ Water Parks:**
  Manage complex networks of pumps and filtration systems across multiple attractions from a single dashboard.

### 🔌 How to connect real devices?

* **IoT Gateway:** The solution is designed to use the [ThingsBoard IoT Gateway](https://thingsboard.io/docs/iot-gateway/) to connect Modbus TCP/UDP or RTU devices.
* **Modbus Protocol:** Direct integration with PLCs controlling valves, pumps, and heaters via [Modbus Connector](https://thingsboard.io/docs/iot-gateway/config/modbus/).
* **MQTT API:** Alternatively, integrate custom controllers using the [MQTT Gateway API](https://thingsboard.io/docs/paas/reference/gateway-api/overview/).
